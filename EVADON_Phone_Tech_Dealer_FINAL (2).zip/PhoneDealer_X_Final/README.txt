EVADON — PHONE & TECH DEALER X (browser game)

HOW TO RUN
1. Extract this ZIP file.
2. Open the PhoneDealer_X_Final folder.
3. Open index.html in Google Chrome or another modern browser.

IN THE GAME
- 30+ phone models plus headphones, earbuds, Xbox, PlayStation, Nintendo, gaming mice, keyboards, PCs, laptops, monitors, VR gear, and accessories.
- Category filters for Phones, Consoles, Audio, and PC gear.
- Buy/sell market, inventory, random selling prices, XP, levels, upgrades, daily mission.
- Daily free spin, paid Phone Spin, 2D Coin Catcher mini-game.
- Animated interface, mobile-friendly layout, and local save.

LOGIN AND SAVING
The username and demo password are stored in this browser on this device for convenience. This is not secure authentication and is not an online account. Use a made-up password, never a real password. Save data uses browser localStorage; clearing site data can erase progress. For real secure accounts and cross-device sync, the game needs a backend server and secure authentication.

ANDROID APK
This ZIP is a browser game, not an APK yet. To make a real Android APK, it must be packaged with an Android wrapper/toolchain and tested on a device.
